# RegisterContact
Haz una aplicación móvil que se compondrá de dos activities
Activity 1:

Será un formulario de contacto donde solicites al usuario los siguientes datos:

Nombre completo
Fecha de nacimiento (picker de fecha)
teléfono
Email
Descripción del contacto


Activity 2:

Será una pantalla de confirmación de datos en donde se deberán mostrar todos los datos ingresados por el usuario.

Al final de los datos, debes colocar un botón de "Editar datos". Este botón deberá llevar a la actividad anterior la cual tendrá los datos precargados en los campos para poder ser editados una vez más.
